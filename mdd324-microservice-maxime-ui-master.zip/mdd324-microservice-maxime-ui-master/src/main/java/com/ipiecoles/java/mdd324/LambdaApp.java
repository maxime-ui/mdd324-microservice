package com.ipiecoles.java.mdd324;

public class LambdaApp {
}
