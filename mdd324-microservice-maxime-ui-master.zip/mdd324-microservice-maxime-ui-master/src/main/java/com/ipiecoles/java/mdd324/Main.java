package com.ipiecoles.java.mdd324;

public class Main {
    public static void main(String[] args) {

    }
}
